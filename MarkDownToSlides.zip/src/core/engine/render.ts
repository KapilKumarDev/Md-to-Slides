import { Marp } from '@marp-team/marp-core'
import type MarkdownIt from 'markdown-it'
import type { RenderResult, RenderedSlide } from './types'
import { findUnrecognizedDirectives } from './warnings'

// `script: false` keeps Marp from emitting a browser <script>; HTML stays on Marp's allowlist.
const marp = new Marp({ script: false })

// Marpit's slide tokens carry the source line where each slide starts. Capture them in
// the same parse that produces the HTML, so the app never parses a deck twice.
let slideStartLines: number[] = []
marp.use((md: MarkdownIt) => {
  md.core.ruler.push('slide_start_lines', (state) => {
    slideStartLines = state.tokens
      .filter((token) => token.type === 'marpit_slide_open')
      .map((token) => token.map?.[0] ?? 0)
  })
})

export function render(markdown: string): RenderResult {
  const { html, css, comments } = marp.render(markdown, { htmlAsArray: true })
  const pages = Array.isArray(html) ? html : [html]
  const lastLine = markdown.split('\n').length - 1

  const slides: RenderedSlide[] = pages.map((page, index) => {
    const nextStart = slideStartLines[index + 1]
    return {
      html: page,
      notes: comments[index] ?? [],
      lineRange: {
        start: index === 0 ? 0 : (slideStartLines[index] ?? 0),
        end: nextStart === undefined ? lastLine : nextStart - 1,
      },
    }
  })

  return { css, slides, warnings: findUnrecognizedDirectives(markdown, slides) }
}
